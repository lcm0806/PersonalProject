﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SPUM_TexutreList : MonoBehaviour
{
    public List<Sprite> _spriteList = new List<Sprite>();
}
