using UnityEngine;
using UnityEngine.UI;

public class SPUM_LoadPrefabPanel : MonoBehaviour
{
    public Button SelectButton;
    public Button DeleteButton;
    public Button ConvertButton;
    public Text UnitCodeText;
    public Toggle CheckedButton;
}
